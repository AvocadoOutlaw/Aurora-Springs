# 🏠 St. Denis Villa 5 <Badge type="danger" text="IN WORK"/>
Documentation relating to the [spooni_sd_villa_5](https://spooni-mapping.tebex.io/package/).

___
<br>
<iframe width="560" height="315" src="https://www.youtube.com/embed/" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

## 1. Installation
spooni_sd_villa_5 works Standalone.  

To install spooni_sd_villa_5:
- Download the resource
  - On [Cfx.re Portal](https://portal.cfx.re/)
- Drag and drop the resource into your resources folder
  - `spooni_sd_villa_5`
- Add this ensure in your server.cfg
  ```
    ensure spooni_sd_villa_5
  ```
- At the end, restart the server

## 2. For developers
| Doors                     | Doorhashes
|---------------------------|----------------------------------------------------------------------------------|
| Door                      | `Coming Soon...`